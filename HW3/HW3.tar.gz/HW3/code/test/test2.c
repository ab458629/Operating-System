#include "syscall.h"

main()
        {
                int     n;
                for (n=10;n<=25;n++)
                        PrintInt(n);
        }
