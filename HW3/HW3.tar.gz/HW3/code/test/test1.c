#include "syscall.h"
main(){
	{
		int	n;
		for (n=10;n>5;n--)
			PrintInt(n);
	}
}
